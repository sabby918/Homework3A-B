$(document).ready(load_news);


function load_news() {

 var newsData = news["news"];
 var detailsData = news["news"];

    var template=$("#news-item-template").html();
    var html_maker = new htmlMaker(template); 
    var html = html_maker.getHTML(newsData);
    $("#news").html(html);
    
    //var template=$("#news-detail-template").html();
   //var html_maker = new htmlMaker(template); 
    //var html = html_maker.getHTML(detailsData);
    //$("#detail").html(html);
    
    

$('#toggle').on('click',function(){ 
    
    var togglesrc = $("#toggle").attr('src');
    if( togglesrc=="data/pause.png"){
        

        $("#toggle").attr('src',"data/play.png");
        $("#news").attr('class','marquee_paused');
        
        
    }
    else {
        
        $("#toggle").attr('src',"data/pause.png");
        $("#news").attr('class','marquee');    
    }
  
    });    
    
    
    
 
    
}
 







